<?php

    $numero = $_POST["numero"];
	$data = $_POST["data"];
    $firma = $_POST["firma"];
    $endereco = $_POST["endereco"];
    $complemento = $_POST["complemento"];
    $bairro = $_POST["bairro"];
    $cidade = $_POST["cidade"];
    $estado = $_POST["estado"];
    $cep = $_POST["cep"];
    $cnpj = $_POST["cnpj"];
    $inscri = $_POST["inscri"];
    $telefone = $_POST["telefone"];
    $celular = $_POST["celular"];
	$email =  $_POST["email"];
	$obs = $_POST["obs"];

    function validaCNPJ($cnpj2) {
            
        $cnpj2 = preg_replace("/[^0-9]/", "", $cnpj2);
        $cnpj2 = str_pad($cnpj2, 14, '0', STR_PAD_LEFT);
         
        if (strlen($cnpj2) != 14) {
            return false;
        } else if ($cnpj2 == '00000000000000' || 
            $cnpj2 == '11111111111111' || 
            $cnpj2 == '22222222222222' || 
            $cnpj2 == '33333333333333' || 
            $cnpj2 == '44444444444444' || 
            $cnpj2 == '55555555555555' || 
            $cnpj2 == '66666666666666' || 
            $cnpj2 == '77777777777777' || 
            $cnpj2 == '88888888888888' || 
            $cnpj2 == '99999999999999') {
            return false;
            
         } else {   
            $j = 5;
            $k = 6;
            $soma1 = "";
            $soma2 = "";
    
            for ($i = 0; $i < 13; $i++) {
                $j = $j == 1 ? 9 : $j;
                $k = $k == 1 ? 9 : $k;
                $soma2 += ($cnpj2[$i] * $k);
    
                if ($i < 12) {
                    $soma1 += ($cnpj2[$i] * $j);
                }
                $k--;
                $j--;
            }
            $digito1 = $soma1 % 11 < 2 ? 0 : 11 - $soma1 % 11;
            $digito2 = $soma2 % 11 < 2 ? 0 : 11 - $soma2 % 11;

            return (($cnpj2[12] == $digito1) and ($cnpj2[13] == $digito2));
        }
    }
    if(empty($cnpj)) {
        echo "<b>O campo CNPJ deve ser preenchido.</b>";
        include "cadastro-cliente.php";
        die;
    }else{
        if(validaCNPJ($cnpj)){
            if(empty($telefone && $celular && $email)) {
                echo "<b>Ao menos 1 dos campos de contato (Telefone, Celular, Email) deve ser preenchido.</b>";
                include "cadastro-cliente.php";
                die;
            }

            if(!empty($email)){
                if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
                echo "<b>O campo email não se parece com um email.</b>";
                include "cadastro-cliente.php";
                die;
                }
            }

            if(!empty($celular)){
                if (strlen($celular) != 11) {
                    return false;
                }
            }
            
            if(!empty($telefone)){
                if (strlen($telefone) != 10) {
                    return false;
                }
            }

            if(empty($firma)){
                echo "<b>O campo Firma deve ser preenchido.</b>";
                include "cadastro-cliente.php";
                die;
            }
        
        }else{
            echo "<b>O campo CNPJ preenchido incorretamente</b>";
            include "cadastro-cliente.php";
            die;
        }
    }
    $f = fopen("cadastrados.csv","a");
    fputcsv($f, array($numero, $data, $firma, $endereco, $complemento, $bairro, $cidade, $estado, $cep, $cnpj, $inscri, $telefone, $celular, $email, $obs));
    fclose($f);

    // redirecionamento
    header('location: obrigado.php');
?>