<html>
    <head>
        <style>
            div{
                margin: 0 auto;
                width: 500px;
                height: 250px;
                padding: 1em;
                border: 1px solid #CCC;
                border-radius: 1em;
                background-color: #CCC;
            }
            h1{
                padding: 1em;
            }
            button{
                margin: 0 auto;
                padding: 1em;
                border: 1px solid #CCC;
                border-radius: 1em;
            }
            body{
                background-color: #353839;
            }
        </style>
    </head>
    <body>
        <div>
            <h1>Obrigado pela sua mensagem<h1>
            <a href="cadastro-cliente.php"><input type="button"value="Voltar"></a>
        </div>
    </body>
</html>