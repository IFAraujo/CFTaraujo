<?php

// A função isset retorna verdadeiro se a variável não está definida.
// Aqui estou assumindo que se o nome não está, nenhuma outra também estará.
// Nesse todas são inicializadas com vazio.
// Se as variáveis forem inicializadas em outro código PHP que inclua esse,
// a variável nome estará definida e a lógica não entrará nesse if.
if(!isset($cnpj)) 
{
    $numero = "";
	$data = "";
    $firma = "";
    $endereco = "";
    $complemento = "";
    $bairro = "";
    $cidade = "";
    $estado = "";
    $cep = "";
    $cnpj = "";
    $inscri = "";
    $telefone = "";
    $celular = "";
	$email = "";
	$obs = "";
}

?>
<html>
    <head>
        <style>
            form {
                margin: 0 auto;
                width: 700px;
                padding: 1em;
                border: 1px solid #000;
                border-radius: 1em;
                background-color: #CCC;
                text-align:justify;
            }
            body{
                background-color: #353839;
            }
            h1{
                text-align: center;
                color: #353839;
            }
            button{
                width: 100px;
                height: 30px;
            }
        </style>
    </head>
    <body>
         <form method="post" action="cadastrar.php">
            <h1>Cadastro Cliente</h1>
            <p>Nº: <input type="text" name="numero" size="50" value="<?=$numero?>" placeholder="Ex. 726"> Data: <input type="date" name="data" size="80" value="<?=$data?>"></p>
            <p>Firma: <input type="text" name="firma" size="80" value="<?=$firma?>"></p>                
            <p>Endereço: <input type="text" name="endereco" size="75" value="<?=$endereco?>" placeholder="Ex. 'Rua tiragosto, 123'" ></p>
            <p>Complemento: <input type="text" name="complemento" size="65" value="<?=$complemento?>" placeholder="Ex. 'Lote x Quadra z' OU 'em frente ao Mercado'"></p>
            <p>Bairro: <input type="text" name="bairro" size="80" value="<?=$bairro?>" placeholder="Ex. 'Ipanema'"></p>
            <p>Cidade: <input type="text" name="cidade" size="60" value="<?=$cidade?>" placeholder="Ex. 'Rio de Janeiro'">
                Estado:
            <select name="estado">
                    <option value=""></option>
                    <option value="AC" <?= $estado=="AC" ? "selected" : "" ?> >AC</option>
                    <option value="AL" <?= $estado=="AL" ? "selected" : "" ?> >AL</option>
                    <option value="AP" <?= $estado=="AP" ? "selected" : "" ?> >AP</option>
                    <option value="AM" <?= $estado=="AM" ? "selected" : "" ?> >AM</option>
                    <option value="BA" <?= $estado=="BA" ? "selected" : "" ?> >BA</option>
                    <option value="CE" <?= $estado=="CE" ? "selected" : "" ?> >CE</option>
                    <option value="DF" <?= $estado=="DF" ? "selected" : "" ?> >DF</option>
                    <option value="ES" <?= $estado=="ES" ? "selected" : "" ?> >ES</option>
                    <option value="GO" <?= $estado=="GO" ? "selected" : "" ?> >GO</option>
                    <option value="MA" <?= $estado=="MA" ? "selected" : "" ?> >MA</option>
                    <option value="MT" <?= $estado=="MT" ? "selected" : "" ?> >MT</option>
                    <option value="MS" <?= $estado=="MS" ? "selected" : "" ?> >MS</option>
                    <option value="MG" <?= $estado=="MG" ? "selected" : "" ?> >MG</option>
                    <option value="PA" <?= $estado=="PA" ? "selected" : "" ?> >PA</option>
                    <option value="PB" <?= $estado=="PB" ? "selected" : "" ?> >PB</option>
                    <option value="PR" <?= $estado=="PR" ? "selected" : "" ?> >PR</option>
                    <option value="PE" <?= $estado=="PE" ? "selected" : "" ?> >PE</option>
                    <option value="PI" <?= $estado=="PI" ? "selected" : "" ?> >PI</option>
                    <option value="RJ" <?= $estado=="RJ" ? "selected" : "" ?> >RJ</option>
                    <option value="RN" <?= $estado=="RN" ? "selected" : "" ?> >RN</option>
                    <option value="RS" <?= $estado=="RS" ? "selected" : "" ?> >RS</option>
                    <option value="RO" <?= $estado=="RO" ? "selected" : "" ?> >RO</option>
                    <option value="RR" <?= $estado=="RR" ? "selected" : "" ?> >RR</option>
                    <option value="SC" <?= $estado=="SC" ? "selected" : "" ?> >SC</option>
                    <option value="SP" <?= $estado=="SP" ? "selected" : "" ?> >SP</option>
                    <option value="SE" <?= $estado=="SE" ? "selected" : "" ?> >SE</option>
                    <option value="TO" <?= $estado=="TO" ? "selected" : "" ?> >TO</option>
            </select>
            </p>
            <p>CEP: <input type="text" name="cep" size="80" value="<?=$cep?>" placeholder="Ex. '12345678'"></p>
            <p>CNPJ: <input type="text" name="cnpj" size="80" value="<?=$cnpj?>" placeholder="Ex. '12345678912345'"></p>
            <p>Inscri: <input type="text" name="inscri" size="80" value="<?=$inscri?>"></p>
            <p>Telefone: <input type="text" name="telefone" size="80" value="<?=$telefone?>" placeholder="Ex. '2133334565'"></p>
            <p>Celular: <input type="text" name="celular" size="80" value="<?=$celular?>" placeholder="Ex. '21995687423'"></p>
            <p>Email: <input type="text" name="email" size="80" value="<?=$email?>" placeholder="Ex. 'nome@email.com'"></p>
            <p>Obs:</p>
            <p><textarea name="obs" rows="6" cols="80"><?=$obs?></textarea></p>
            <p><button type="submit">Cadastrar</button></p>
        </form>
    </body>
</html>